package com.poe.javatos.exception;

// exception controllée (checked - try/catch)
public class POEException extends Exception{

	public POEException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public POEException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
