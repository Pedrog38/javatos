package com.poe.javatos.exception;

//exception non controllée (unchecked - try/catch pas obligatoire)
public class POERuntimeException extends RuntimeException {

	public POERuntimeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public POERuntimeException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
}
