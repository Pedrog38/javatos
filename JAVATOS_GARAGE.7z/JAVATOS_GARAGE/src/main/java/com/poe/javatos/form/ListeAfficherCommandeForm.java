package com.poe.javatos.form;

import java.util.List;

public class ListeAfficherCommandeForm {
	private List<AfficherCommandeForm> listeCommandeForm;
	private Integer index;
	
	public List<AfficherCommandeForm> getListeCommandeForm() {
		return listeCommandeForm;
	}
	public void setListeCommandeForm(List<AfficherCommandeForm> listeCommandeForm) {
		this.listeCommandeForm = listeCommandeForm;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	

}
