package com.poe.javatos.global;

public enum StatutCommande 
{
	//Commande
	Nouvelle,EnTraitement,Prete,Livree;
	
}
