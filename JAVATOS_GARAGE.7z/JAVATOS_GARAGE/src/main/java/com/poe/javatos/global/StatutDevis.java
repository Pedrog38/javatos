package com.poe.javatos.global;

public class StatutDevis 
{
	//Devis
	public static final String Nouveau="Nouveau";
	public static final String Annule="Annule";
	public static final String Valide="Valide";
}
