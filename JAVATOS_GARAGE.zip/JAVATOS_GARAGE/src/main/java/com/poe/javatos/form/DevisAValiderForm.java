package com.poe.javatos.form;

import com.poe.javatos.bean.Devis;

public class DevisAValiderForm {
	
	private Devis devis;
	private Float prixDevis;
	public Devis getDevis() {
		return devis;
	}
	public void setDevis(Devis devis) {
		this.devis = devis;
	}
	public Float getPrixDevis() {
		return prixDevis;
	}
	public void setPrixDevis(Float prixDevis) {
		this.prixDevis = prixDevis;
	}
	
	
}
