package com.poe.javatos.form;

import java.util.List;

public class ListeCommandeForm {
	private List<CommandeForm> listeCommandeForm;
	private Integer index;
	
	public List<CommandeForm> getListeCommandeForm() {
		return listeCommandeForm;
	}
	public void setListeCommandeForm(List<CommandeForm> listeCommandeForm) {
		this.listeCommandeForm = listeCommandeForm;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	

}
