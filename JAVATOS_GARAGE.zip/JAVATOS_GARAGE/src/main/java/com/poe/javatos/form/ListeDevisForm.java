package com.poe.javatos.form;

import java.util.List;

public class ListeDevisForm {
	private List<DevisForm> listeDevisForm;
	private Integer index;
	

	public List<DevisForm> getListeDevisForm() {
		return listeDevisForm;
	}
	public void setListeDevisForm(List<DevisForm> listeDevisForm) {
		this.listeDevisForm = listeDevisForm;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	

}
