package com.poe.javatos.global;

public class StatutCommande 
{

	//Commande
	public static final String Nouvelle="Nouvelle";
	public static final String EnTraitement="EnTraitement";
	public static final String Prete="Prete";
	public static final String Livree="Livree";
	
	
	
}
