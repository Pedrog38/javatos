package com.poe.javatos.global;

public class StatutLigneCommande 
{
	//LigneCommande
	public static final String NonRenseignee="NonRenseignee";
	public static final String EnCommandeFournisseur="EnCommandeFournisseur";
	public static final String Reservee="Reservee";
}
