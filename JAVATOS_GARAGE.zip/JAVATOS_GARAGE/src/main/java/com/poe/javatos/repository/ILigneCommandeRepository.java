package com.poe.javatos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.poe.javatos.bean.LigneCommande;

@Repository
public interface ILigneCommandeRepository extends JpaRepository<LigneCommande, Integer>
{
	@Query(" select lc from LigneCommande lc where lc.commande.id = ?1")
    List<LigneCommande> findByCommandeLigneCommande(Integer idCommande);
	
	@Query(" select lc from LigneCommande lc where lc.statut = ?1")
    List<LigneCommande> findByStatutLignesCommande(String statut);
	
	@Query(" select lc from LigneCommande lc where lc.commande.id = ?1 and lc.statut = ?2")
    List<LigneCommande> findByCommandeLigneCommandeStatut(Integer idCommande, String statut);

	@Query(" select lc from LigneCommande lc where lc.commande.id = ?1 and (lc.statut = ?2 or lc.statut = ?3)")
    List<LigneCommande> findByCommandeLigneCommandeStatuts(Integer idCommande, String statut1, String statut2);
}
