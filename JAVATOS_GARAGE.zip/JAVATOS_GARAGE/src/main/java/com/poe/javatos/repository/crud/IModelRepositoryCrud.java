package com.poe.javatos.repository.crud;


import org.springframework.data.jpa.repository.JpaRepository;
import com.poe.javatos.bean.Model;

public interface IModelRepositoryCrud extends JpaRepository<Model, Integer>{
		

}
