package com.poe.javatos.repository.crud;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poe.javatos.bean.StatutClient;

public interface IStatutClientRepositoryCrud extends JpaRepository<StatutClient, Integer> {

}
