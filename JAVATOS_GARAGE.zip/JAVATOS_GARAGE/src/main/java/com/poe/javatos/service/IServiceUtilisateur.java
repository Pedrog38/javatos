package com.poe.javatos.service;

public interface IServiceUtilisateur 
{
	String getChemin(Integer idUtilisateur);
}
