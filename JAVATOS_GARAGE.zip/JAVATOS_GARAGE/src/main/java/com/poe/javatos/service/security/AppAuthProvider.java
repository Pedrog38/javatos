package com.poe.javatos.service.security;

public class AppAuthProvider {

}
